<?php
echo "<br>1. <a href='alta.php'>Alta</a>";
echo "<br>2. <a href='baja.php'>Baja</a>";
echo "<br>3. <a href='consulta.php'>Consulta</a>";
echo "<br>4. <a href='modifica2.php'>Modifica</a>";
echo "<br><br><form><a href='login_form.html'/><input type='button' value='SORTIR'></a>";
?>